/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.facebook.react;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.facebook.react";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final boolean ENABLE_PERFETTO = false;
  // Field from default config.
  public static final int EXOPACKAGE_FLAGS = 0;
  // Field from default config.
  public static final boolean IS_INTERNAL_BUILD = false;
  // Field from default config.
  public static final boolean UNSTABLE_ENABLE_FUSEBOX_RELEASE = false;
}
